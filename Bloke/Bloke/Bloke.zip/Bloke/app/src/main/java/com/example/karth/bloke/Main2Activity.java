package com.example.karth.bloke;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Main2Activity extends AppCompatActivity {






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final JSONArray response;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button plot = findViewById(R.id.button1);
        Button block = findViewById(R.id.parse);

        //   jsonObject s = getIntent().getStringExtra("chain");

        try {
            response = new JSONArray(getIntent().getStringExtra("key"));


            block.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(Main2Activity.this, MainBLOCKActivity.class).putExtra("key1", response.toString());

                    startActivity(in);
                }
            });

            plot.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(Main2Activity.this, MainPLOTActivity.class).putExtra("key2", response.toString());
                    startActivity(in);

                }
            });


    }
    catch (JSONException e) {
        e.printStackTrace();
    }
}}
