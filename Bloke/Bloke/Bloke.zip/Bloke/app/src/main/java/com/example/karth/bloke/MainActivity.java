package com.example.karth.bloke;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




import java.io.Console;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private TextView mTextViewResult;
    private RequestQueue mQueue;
    private Context mContext;
    private Activity mActivity;
    private EditText barcode_input;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button barcode = findViewById(R.id.bar_code);

        mContext = getApplicationContext();
        mActivity = MainActivity.this;

        mQueue = Volley.newRequestQueue(this);

        barcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                request();
            }
        });




    }

    private void request()
    {

        barcode_input = (EditText)findViewById(R.id.bar_code_input);



        final TextView mTextView = (TextView) findViewById(R.id.textv);


        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://10.0.2.2:3000/getChain";

        //StringRequest stringRequest = new StringRequest(Request.Method.GET, url+"?barcodes="+barcode_input.getText().toString(),
          //      new Response.Listener<String>()

                JsonArrayRequest stringRequest = new JsonArrayRequest(Request.Method.GET, url+"?barcodes="+barcode_input.getText().toString(), null,
                new Listener<JSONArray>(){


                    @Override
                    public void onResponse(JSONArray response)
                    {
                        mTextView.setVisibility(View.INVISIBLE);



                        //mTextView.setText("Response is: "+ response);
                        //mTextView.setVisibility(View.VISIBLE);
                        //Change to > 0
                        if(response.length() >=1)
                        {
                           // mTextView.setVisibility(View.INVISIBLE);
                            Intent in = new Intent(MainActivity.this, Main2Activity.class);
                            in.putExtra("key", response.toString());
                            startActivity(in);
                        }
                        else
                        {


                                mTextView.setText("Bar Code could not be found!");
                                mTextView.setVisibility(View.VISIBLE);


                        }
                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mTextView.setText("That didn't work!");
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);


    }

}